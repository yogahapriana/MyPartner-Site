module PartnersHelper
end
