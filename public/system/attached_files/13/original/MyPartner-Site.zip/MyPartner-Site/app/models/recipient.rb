class Recipient < ActiveRecord::Base
end
