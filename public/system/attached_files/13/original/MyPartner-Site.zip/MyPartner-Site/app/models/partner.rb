class Partner < ActiveRecord::Base
  belongs_to :group
end
