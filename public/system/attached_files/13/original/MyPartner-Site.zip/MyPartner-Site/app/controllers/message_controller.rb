class MessageController < ApplicationController
  def index
  end

  def choose_recipients
    @group = Group.find(params[:id])
    @partners = @group.partners
  end

  def send_email
#    @message = Message.new(params[:message])
#    redirect_to create_message_path
  end

  def create_message
    @partners = params["partners"]
    @partners.each do |partner|
      Recipient.create(:email_recipient => partner)
    end
    @subject = params["subject"]
    @text = params["text"]
    Message.create(:subject => @subject, :text => @text)
  end
end
