require 'test_helper'

class PartnersHelperTest < ActionView::TestCase
end
